package com.example.data.repository

import com.example.data.db.GameDao
import com.example.data.db.HighScoreEntity
import com.example.data.db.UserStatsEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class GameRepository(private val gameDao: GameDao) {

    val topHighScores: Flow<List<HighScoreEntity>> = gameDao.getTopHighScores()

    val userStats: Flow<UserStatsEntity> = gameDao.getUserStats().map { stats ->
        stats ?: UserStatsEntity()
    }

    suspend fun saveHighScore(distanceMeters: Int, coinsCollected: Int, jetpackSkinId: String) {
        val entity = HighScoreEntity(
            distanceMeters = distanceMeters,
            coinsCollected = coinsCollected,
            jetpackSkinId = jetpackSkinId
        )
        gameDao.insertHighScore(entity)
    }

    suspend fun addCoinsAndRecordDistance(coinsEarned: Int, distanceMeters: Int) {
        gameDao.getUserStats().collect { current ->
            val stats = current ?: UserStatsEntity()
            val newTotalCoins = stats.totalCoins + coinsEarned
            val newHighestDist = maxOf(stats.highestDistance, distanceMeters)
            val updated = stats.copy(
                totalCoins = newTotalCoins,
                highestDistance = newHighestDist
            )
            gameDao.saveUserStats(updated)
            return@collect
        }
    }

    suspend fun unlockSkin(skinId: String, cost: Int): Boolean {
        var success = false
        gameDao.getUserStats().collect { current ->
            val stats = current ?: UserStatsEntity()
            if (stats.totalCoins >= cost) {
                val unlockedSet = stats.unlockedSkinIds.split(",").toMutableSet()
                unlockedSet.add(skinId)
                val updated = stats.copy(
                    totalCoins = stats.totalCoins - cost,
                    unlockedSkinIds = unlockedSet.joinToString(","),
                    equippedSkinId = skinId
                )
                gameDao.saveUserStats(updated)
                success = true
            }
            return@collect
        }
        return success
    }

    suspend fun equipSkin(skinId: String) {
        gameDao.getUserStats().collect { current ->
            val stats = current ?: UserStatsEntity()
            val unlockedSet = stats.unlockedSkinIds.split(",")
            if (unlockedSet.contains(skinId)) {
                val updated = stats.copy(equippedSkinId = skinId)
                gameDao.saveUserStats(updated)
            }
            return@collect
        }
    }

    suspend fun upgradeStat(statType: String, cost: Int): Boolean {
        var success = false
        gameDao.getUserStats().collect { current ->
            val stats = current ?: UserStatsEntity()
            if (stats.totalCoins >= cost) {
                val updated = when (statType) {
                    "shield" -> stats.copy(
                        totalCoins = stats.totalCoins - cost,
                        shieldLevel = stats.shieldLevel + 1
                    )
                    "magnet" -> stats.copy(
                        totalCoins = stats.totalCoins - cost,
                        magnetLevel = stats.magnetLevel + 1
                    )
                    "multiplier" -> stats.copy(
                        totalCoins = stats.totalCoins - cost,
                        multiplierLevel = stats.multiplierLevel + 1
                    )
                    else -> stats
                }
                gameDao.saveUserStats(updated)
                success = true
            }
            return@collect
        }
        return success
    }
}
