package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "high_scores")
data class HighScoreEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val distanceMeters: Int,
    val coinsCollected: Int,
    val jetpackSkinId: String,
    val timestamp: Long = System.currentTimeMillis()
)
