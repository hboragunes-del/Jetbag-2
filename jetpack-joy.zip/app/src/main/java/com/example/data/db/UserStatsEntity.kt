package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey
    val id: Int = 1,
    val totalCoins: Int = 0,
    val highestDistance: Int = 0,
    val equippedSkinId: String = "classic",
    val unlockedSkinIds: String = "classic", // Comma-separated list of unlocked skin ids
    val shieldLevel: Int = 1,
    val magnetLevel: Int = 1,
    val multiplierLevel: Int = 1
)
