package com.example.domain.model

enum class PowerUpType {
    SHIELD,
    MAGNET,
    BOOST,
    MULTIPLIER
}

sealed class Collectible {
    abstract val id: Long
    abstract var x: Float
    abstract var y: Float
    abstract var isCollected: Boolean

    data class Coin(
        override val id: Long,
        override var x: Float,
        override var y: Float,
        val radius: Float = 16f,
        val value: Int = 1,
        override var isCollected: Boolean = false
    ) : Collectible()

    data class PowerUp(
        override val id: Long,
        override var x: Float,
        override var y: Float,
        val type: PowerUpType,
        val radius: Float = 24f,
        override var isCollected: Boolean = false
    ) : Collectible()
}
