package com.example.domain.model

import androidx.compose.ui.graphics.Color

data class JetpackSkin(
    val id: String,
    val name: String,
    val description: String,
    val cost: Int,
    val primaryColor: Color,
    val secondaryColor: Color,
    val flameColor: Color,
    val particleColor: Color
) {
    companion object {
        val ALL_SKINS = listOf(
            JetpackSkin(
                id = "classic",
                name = "Klasik Jetpack",
                description = "Standart deneysel laboratuvar roketi.",
                cost = 0,
                primaryColor = Color(0xFF64748B),
                secondaryColor = Color(0xFF38BDF8),
                flameColor = Color(0xFFF97316),
                particleColor = Color(0xFFFACC15)
            ),
            JetpackSkin(
                id = "neon",
                name = "Neon Pulse",
                description = "Yüksek hızlı siyan ve mor lazer iticileri.",
                cost = 250,
                primaryColor = Color(0xFF06B6D4),
                secondaryColor = Color(0xFFA855F7),
                flameColor = Color(0xFF22D3EE),
                particleColor = Color(0xFFE879F9)
            ),
            JetpackSkin(
                id = "firestorm",
                name = "Alev Fırtınası",
                description = "Ekstra tutuş ve yanan lav parçacıkları.",
                cost = 600,
                primaryColor = Color(0xFFDC2626),
                secondaryColor = Color(0xFFF59E0B),
                flameColor = Color(0xFFEF4444),
                particleColor = Color(0xFFFB923C)
            ),
            JetpackSkin(
                id = "rainbow",
                name = "Gökkuşağı Yıldızı",
                description = "Işıl ışıl parıldayan kozmik yıldız tozları.",
                cost = 1200,
                primaryColor = Color(0xFFEC4899),
                secondaryColor = Color(0xFF8B5CF6),
                flameColor = Color(0xFF10B981),
                particleColor = Color(0xFFFBBF24)
            ),
            JetpackSkin(
                id = "cyber_gold",
                name = "Siber Altın",
                description = "Saf altından işlenmiş elit şampiyon jetpack'i.",
                cost = 2500,
                primaryColor = Color(0xFFF59E0B),
                secondaryColor = Color(0xFFFEF08A),
                flameColor = Color(0xFFFACC15),
                particleColor = Color(0xFFFFFFFF)
            )
        )

        fun getById(id: String): JetpackSkin {
            return ALL_SKINS.find { it.id == id } ?: ALL_SKINS.first()
        }
    }
}
