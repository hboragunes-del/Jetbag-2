package com.example.domain.model

import androidx.compose.ui.graphics.Color

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    var size: Float,
    val maxLife: Float,
    var currentLife: Float = maxLife,
    var alpha: Float = 1f
)
