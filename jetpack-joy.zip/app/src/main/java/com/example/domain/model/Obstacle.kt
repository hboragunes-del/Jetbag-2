package com.example.domain.model

sealed class Obstacle {
    abstract val id: Long
    abstract var x: Float
    abstract val isPassed: Boolean

    data class Zapper(
        override val id: Long,
        override var x: Float,
        var y: Float,
        val length: Float = 160f,
        val angleDeg: Float = 0f, // 0 = horizontal, 45 = diagonal, 90 = vertical
        override var isPassed: Boolean = false
    ) : Obstacle()

    data class Missile(
        override val id: Long,
        override var x: Float,
        var y: Float,
        val speed: Float = 14f,
        var warningTimerSec: Float = 1.2f, // Warning before missile launches
        val isWarningActive: Boolean = true,
        override var isPassed: Boolean = false
    ) : Obstacle()

    data class LaserField(
        override val id: Long,
        override var x: Float,
        val width: Float = 80f,
        val topY: Float,
        val bottomY: Float,
        var cycleTimerSec: Float = 0f,
        var isActive: Boolean = false,
        override var isPassed: Boolean = false
    ) : Obstacle()
}
