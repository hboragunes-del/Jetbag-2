package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.game.GameOverDialog
import com.example.ui.game.GameCanvas
import com.example.ui.game.GameMode
import com.example.ui.game.GamePlayOverlay
import com.example.ui.game.GameViewModel
import com.example.ui.game.LeaderboardScreen
import com.example.ui.game.MainMenuOverlay
import com.example.ui.game.PauseDialog
import com.example.ui.game.ShopScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    JetpackGameApp()
                }
            }
        }
    }
}

@Composable
fun JetpackGameApp(
    viewModel: GameViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize()) {
        // Main Game Canvas rendering always
        GameCanvas(
            state = state,
            onThrustChange = { isThrusting -> viewModel.onThrustChange(isThrusting) },
            onCanvasSizeChanged = { w, h -> viewModel.setCanvasDimensions(w, h) },
            onGameTick = { dt -> viewModel.updateGameTick(dt) },
            modifier = Modifier.fillMaxSize()
        )

        // Game Overlays based on state.gameMode
        when (state.gameMode) {
            GameMode.MENU -> {
                MainMenuOverlay(
                    state = state,
                    onStartGame = { viewModel.startGame() },
                    onOpenShop = { viewModel.openShop() },
                    onOpenLeaderboard = { viewModel.openLeaderboard() }
                )
            }
            GameMode.PLAYING -> {
                GamePlayOverlay(
                    state = state,
                    onPauseGame = { viewModel.pauseGame() }
                )
            }
            GameMode.PAUSED -> {
                GamePlayOverlay(
                    state = state,
                    onPauseGame = {}
                )
                PauseDialog(
                    onResume = { viewModel.resumeGame() },
                    onRestart = { viewModel.startGame() },
                    onMenu = { viewModel.backToMenu() }
                )
            }
            GameMode.GAME_OVER -> {
                GameOverDialog(
                    state = state,
                    onPlayAgain = { viewModel.startGame() },
                    onOpenShop = { viewModel.openShop() },
                    onMenu = { viewModel.backToMenu() }
                )
            }
            GameMode.SHOP -> {
                ShopScreen(
                    state = state,
                    onPurchaseSkin = { skin -> viewModel.purchaseSkin(skin) },
                    onUpgradeStat = { stat, cost -> viewModel.upgradeStat(stat, cost) },
                    onBack = { viewModel.backToMenu() }
                )
            }
            GameMode.LEADERBOARD -> {
                LeaderboardScreen(
                    state = state,
                    onBack = { viewModel.backToMenu() }
                )
            }
        }
    }
}
