package com.example.ui.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.domain.model.Collectible
import com.example.domain.model.Obstacle
import com.example.domain.model.PowerUpType
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GameCanvas(
    state: GameUiState,
    onThrustChange: (Boolean) -> Unit,
    onCanvasSizeChanged: (Float, Float) -> Unit,
    onGameTick: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // Continuous 60fps Game Loop using withFrameNanos
    LaunchedEffect(state.gameMode) {
        if (state.gameMode == GameMode.PLAYING) {
            var lastFrameTimeNanos = 0L
            while (true) {
                withFrameNanos { frameTimeNanos ->
                    if (lastFrameTimeNanos != 0L) {
                        val dtSec = ((frameTimeNanos - lastFrameTimeNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                        onGameTick(dtSec)
                    }
                    lastFrameTimeNanos = frameTimeNanos
                }
            }
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .testTag("game_canvas")
            .pointerInput(state.gameMode) {
                if (state.gameMode == GameMode.PLAYING) {
                    detectTapGestures(
                        onPress = {
                            onThrustChange(true)
                            tryAwaitRelease()
                            onThrustChange(false)
                        }
                    )
                }
            }
    ) {
        val w = size.width
        val h = size.height
        if (w > 0 && h > 0) {
            onCanvasSizeChanged(w, h)
        }

        val ceilingY = h * 0.08f
        val floorY = h * 0.90f

        // 1. Render Futuristic Lab Corridor Background
        drawCorridorBackground(w, h, ceilingY, floorY, state.backgroundOffset)

        // 2. Render Obstacles
        for (obs in state.obstacles) {
            drawObstacle(obs, ceilingY, floorY)
        }

        // 3. Render Collectibles
        for (col in state.collectibles) {
            if (!col.isCollected) {
                drawCollectible(col)
            }
        }

        // 4. Render Particles
        for (p in state.particles) {
            drawCircle(
                color = p.color.copy(alpha = p.alpha),
                radius = p.size,
                center = Offset(p.x, p.y)
            )
        }

        // 5. Render Player Hero with Jetpack
        drawPlayerHero(
            x = state.playerX,
            y = state.playerY,
            radius = state.playerRadius,
            isThrusting = state.isThrusting,
            hasShield = state.hasShield,
            isBoost = state.isBoostActive,
            skin = state.equippedSkin
        )

        // 6. Render Floating Texts
        for (ft in state.floatingTexts) {
            drawCircle(
                color = Color(ft.colorHex).copy(alpha = (ft.lifeSec).coerceIn(0f, 1f)),
                radius = 4f,
                center = Offset(ft.x, ft.y)
            )
        }
    }
}

private fun DrawScope.drawCorridorBackground(
    w: Float,
    h: Float,
    ceilingY: Float,
    floorY: Float,
    bgOffset: Float
) {
    // Deep Sci-fi Space Background Gradient
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF090D16),
                Color(0xFF0F172A),
                Color(0xFF1E1B4B),
                Color(0xFF0F172A),
                Color(0xFF090D16)
            )
        ),
        size = Size(w, h)
    )

    // Horizontal grid lines
    val gridColor = Color(0x1538BDF8)
    val gridSpacing = 80f
    var y = ceilingY
    while (y <= floorY) {
        drawLine(
            color = gridColor,
            start = Offset(0f, y),
            end = Offset(w, y),
            strokeWidth = 2f
        )
        y += gridSpacing
    }

    // Vertical moving grid lines
    var x = - (bgOffset % gridSpacing)
    while (x <= w + gridSpacing) {
        drawLine(
            color = gridColor,
            start = Offset(x, ceilingY),
            end = Offset(x, floorY),
            strokeWidth = 2f
        )
        x += gridSpacing
    }

    // Ceiling bar with hazard style
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A))),
        topLeft = Offset(0f, 0f),
        size = Size(w, ceilingY)
    )
    drawLine(
        color = Color(0xFF06B6D4),
        start = Offset(0f, ceilingY),
        end = Offset(w, ceilingY),
        strokeWidth = 6f
    )

    // Floor bar with hazard style
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E293B))),
        topLeft = Offset(0f, floorY),
        size = Size(w, h - floorY)
    )
    drawLine(
        color = Color(0xFF06B6D4),
        start = Offset(0f, floorY),
        end = Offset(w, floorY),
        strokeWidth = 6f
    )
}

private fun DrawScope.drawObstacle(obs: Obstacle, ceilingY: Float, floorY: Float) {
    when (obs) {
        is Obstacle.Zapper -> {
            val halfLen = obs.length / 2f
            val rad = Math.toRadians(obs.angleDeg.toDouble())
            val dx = cos(rad).toFloat() * halfLen
            val dy = sin(rad).toFloat() * halfLen

            val start = Offset(obs.x - dx, obs.y - dy)
            val end = Offset(obs.x + dx, obs.y + dy)

            // Outer glowing laser beam
            drawLine(
                color = Color(0x66F59E0B),
                start = start,
                end = end,
                strokeWidth = 20f,
                cap = StrokeCap.Round
            )
            // Core zapper beam
            drawLine(
                color = Color(0xFFFACC15),
                start = start,
                end = end,
                strokeWidth = 8f,
                cap = StrokeCap.Round
            )
            // Center hot white beam
            drawLine(
                color = Color.White,
                start = start,
                end = end,
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )

            // End electrode nodes
            drawCircle(color = Color(0xFFD97706), radius = 14f, center = start)
            drawCircle(color = Color(0xFFFACC15), radius = 8f, center = start)
            drawCircle(color = Color(0xFFD97706), radius = 14f, center = end)
            drawCircle(color = Color(0xFFFACC15), radius = 8f, center = end)
        }
        is Obstacle.Missile -> {
            if (obs.warningTimerSec > 0f) {
                // Warning indicator on the right edge of screen
                val rx = size.width - 50f
                val ry = obs.y.coerceIn(ceilingY + 40f, floorY - 40f)

                drawCircle(color = Color(0x66EF4444), radius = 26f, center = Offset(rx, ry))
                drawCircle(color = Color(0xFFEF4444), radius = 18f, center = Offset(rx, ry))
                
                // Exclamation warning mark
                drawLine(
                    color = Color.White,
                    start = Offset(rx, ry - 8f),
                    end = Offset(rx, ry + 2f),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
                drawCircle(color = Color.White, radius = 2.5f, center = Offset(rx, ry + 7f))
            } else {
                // Rocket body drawing
                val rx = obs.x
                val ry = obs.y

                // Rocket flame tail
                val flamePath = Path().apply {
                    moveTo(rx + 25f, ry - 6f)
                    lineTo(rx + 50f, ry)
                    lineTo(rx + 25f, ry + 6f)
                    close()
                }
                drawPath(flamePath, color = Color(0xFFF97316))

                // Rocket body
                drawRoundRect(
                    color = Color(0xFFDC2626),
                    topLeft = Offset(rx - 25f, ry - 12f),
                    size = Size(50f, 24f),
                    cornerRadius = CornerRadius(12f, 12f)
                )
                // Rocket tip cone
                val nosePath = Path().apply {
                    moveTo(rx - 25f, ry - 12f)
                    lineTo(rx - 40f, ry)
                    lineTo(rx - 25f, ry + 12f)
                    close()
                }
                drawPath(nosePath, color = Color(0xFFFEF08A))

                // Rocket window detail
                drawCircle(color = Color(0xFF38BDF8), radius = 5f, center = Offset(rx, ry))
            }
        }
        is Obstacle.LaserField -> {
            val lx = obs.x
            // Emitters at top & bottom
            drawRect(
                color = Color(0xFF475569),
                topLeft = Offset(lx - 20f, obs.topY - 15f),
                size = Size(40f, 15f)
            )
            drawRect(
                color = Color(0xFF475569),
                topLeft = Offset(lx - 20f, obs.bottomY),
                size = Size(40f, 15f)
            )

            if (obs.isActive) {
                // Glowing active laser beam column
                drawRect(
                    color = Color(0x55EF4444),
                    topLeft = Offset(lx - 16f, obs.topY),
                    size = Size(32f, obs.bottomY - obs.topY)
                )
                drawRect(
                    color = Color(0xFFEF4444),
                    topLeft = Offset(lx - 6f, obs.topY),
                    size = Size(12f, obs.bottomY - obs.topY)
                )
                drawRect(
                    color = Color.White,
                    topLeft = Offset(lx - 2f, obs.topY),
                    size = Size(4f, obs.bottomY - obs.topY)
                )
            } else {
                // Dotted warning line
                drawLine(
                    color = Color(0x66F59E0B),
                    start = Offset(lx, obs.topY),
                    end = Offset(lx, obs.bottomY),
                    strokeWidth = 3f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                )
            }
        }
    }
}

private fun DrawScope.drawCollectible(col: Collectible) {
    when (col) {
        is Collectible.Coin -> {
            // Gold coin with outer shine
            drawCircle(color = Color(0x44FACC15), radius = col.radius + 6f, center = Offset(col.x, col.y))
            drawCircle(color = Color(0xFFEAB308), radius = col.radius, center = Offset(col.x, col.y))
            drawCircle(color = Color(0xFFFEF08A), radius = col.radius * 0.7f, center = Offset(col.x, col.y))
            // Inner coin star mark
            drawCircle(color = Color(0xFFCA8A04), radius = col.radius * 0.35f, center = Offset(col.x, col.y))
        }
        is Collectible.PowerUp -> {
            val bgCol = when (col.type) {
                PowerUpType.SHIELD -> Color(0xFF0284C7)
                PowerUpType.MAGNET -> Color(0xFF7C3AED)
                PowerUpType.BOOST -> Color(0xFF0891B2)
                PowerUpType.MULTIPLIER -> Color(0xFF059669)
            }
            val glowCol = when (col.type) {
                PowerUpType.SHIELD -> Color(0xFF38BDF8)
                PowerUpType.MAGNET -> Color(0xFFA855F7)
                PowerUpType.BOOST -> Color(0xFF22D3EE)
                PowerUpType.MULTIPLIER -> Color(0xFF34D399)
            }

            drawCircle(color = glowCol.copy(alpha = 0.5f), radius = col.radius + 10f, center = Offset(col.x, col.y))
            drawCircle(color = bgCol, radius = col.radius, center = Offset(col.x, col.y))
            drawCircle(color = glowCol, radius = col.radius * 0.75f, center = Offset(col.x, col.y), style = Stroke(width = 3f))

            // Inner icon symbol
            when (col.type) {
                PowerUpType.SHIELD -> {
                    drawCircle(color = Color.White, radius = 8f, center = Offset(col.x, col.y))
                }
                PowerUpType.MAGNET -> {
                    drawRect(color = Color.White, topLeft = Offset(col.x - 6f, col.y - 8f), size = Size(12f, 16f))
                }
                PowerUpType.BOOST -> {
                    val path = Path().apply {
                        moveTo(col.x + 8f, col.y)
                        lineTo(col.x - 8f, col.y - 8f)
                        lineTo(col.x - 4f, col.y)
                        lineTo(col.x - 8f, col.y + 8f)
                        close()
                    }
                    drawPath(path, color = Color.White)
                }
                PowerUpType.MULTIPLIER -> {
                    drawLine(
                        color = Color.White,
                        start = Offset(col.x - 6f, col.y - 6f),
                        end = Offset(col.x + 6f, col.y + 6f),
                        strokeWidth = 4f, cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color.White,
                        start = Offset(col.x + 6f, col.y - 6f),
                        end = Offset(col.x - 6f, col.y + 6f),
                        strokeWidth = 4f, cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawPlayerHero(
    x: Float,
    y: Float,
    radius: Float,
    isThrusting: Boolean,
    hasShield: Boolean,
    isBoost: Boolean,
    skin: com.example.domain.model.JetpackSkin
) {
    // 1. Boost / Shield Forcefield Bubble
    if (isBoost) {
        drawCircle(
            color = Color(0x4422D3EE),
            radius = radius + 22f,
            center = Offset(x, y)
        )
        drawCircle(
            color = Color(0xFF22D3EE),
            radius = radius + 18f,
            center = Offset(x, y),
            style = Stroke(width = 4f)
        )
    } else if (hasShield) {
        drawCircle(
            color = Color(0x3338BDF8),
            radius = radius + 18f,
            center = Offset(x, y)
        )
        drawCircle(
            color = Color(0xFF38BDF8),
            radius = radius + 14f,
            center = Offset(x, y),
            style = Stroke(width = 3f)
        )
    }

    // 2. Jetpack Thruster Backpack attached to hero back
    val jetpackX = x - radius * 0.7f
    val jetpackY = y - radius * 0.2f
    drawRoundRect(
        color = skin.secondaryColor,
        topLeft = Offset(jetpackX - 10f, jetpackY - 14f),
        size = Size(18f, 28f),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // 3. Firing Flame Thruster Cone
    if (isThrusting || isBoost) {
        val flameHeight = if (isBoost) 45f else 30f
        val flamePath = Path().apply {
            moveTo(jetpackX - 8f, jetpackY + 14f)
            lineTo(jetpackX - 1f, jetpackY + 14f + flameHeight)
            lineTo(jetpackX + 6f, jetpackY + 14f)
            close()
        }
        drawPath(flamePath, color = skin.flameColor)

        // Inner white hot core
        val innerFlame = Path().apply {
            moveTo(jetpackX - 4f, jetpackY + 14f)
            lineTo(jetpackX - 1f, jetpackY + 14f + flameHeight * 0.6f)
            lineTo(jetpackX + 2f, jetpackY + 14f)
            close()
        }
        drawPath(innerFlame, color = Color.White)
    }

    // 4. Hero Suit Body
    drawCircle(
        color = skin.primaryColor,
        radius = radius,
        center = Offset(x, y)
    )

    // 5. Hero Helmet Visor (Sci-Fi Glass)
    val visorX = x + radius * 0.35f
    val visorY = y - radius * 0.2f
    drawRoundRect(
        color = Color(0xFF0284C7),
        topLeft = Offset(visorX - 8f, visorY - 8f),
        size = Size(16f, 14f),
        cornerRadius = CornerRadius(5f, 5f)
    )
    drawRoundRect(
        color = Color(0xFF38BDF8),
        topLeft = Offset(visorX - 6f, visorY - 6f),
        size = Size(10f, 6f),
        cornerRadius = CornerRadius(3f, 3f)
    )
}
