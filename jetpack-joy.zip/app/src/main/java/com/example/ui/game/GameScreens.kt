package com.example.ui.game

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.domain.model.JetpackSkin
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainMenuOverlay(
    state: GameUiState,
    onStartGame: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenLeaderboard: () -> Unit
) {
    var showHowToPlay by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xEE090D16),
                        Color(0xEE0F172A),
                        Color(0xEE1E1B4B)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Hero Banner Image
            Card(
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_game_banner_1785866954195),
                    contentDescription = "Game Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Title
            Text(
                text = "JETPACK JOY",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                ),
                color = Color(0xFF38BDF8),
                textAlign = TextAlign.Center
            )

            Text(
                text = "SONSUZ KAÇIŞ VE MACERA",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                ),
                color = Color(0xFFFACC15),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // User High Score & Coins Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x441E293B), RoundedCornerShape(16.dp))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "En Yüksek Skor",
                        tint = Color(0xFFFACC15),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("EN YÜKSEK", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(
                            "${state.userStats.highestDistance} m",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = "Altınlar",
                        tint = Color(0xFFFACC15),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("TOPLAM ALTIN", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(
                            "${state.userStats.totalCoins}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Play Button
            Button(
                onClick = onStartGame,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("start_game_button")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("OYUNA BAŞLA", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Shop & Leaderboard Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenShop,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("open_shop_button")
                ) {
                    Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = Color(0xFF38BDF8))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("MAĞAZA", color = Color.White, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onOpenLeaderboard,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("open_leaderboard_button")
                ) {
                    Icon(Icons.Default.Leaderboard, contentDescription = null, tint = Color(0xFFFACC15))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SKORLAR", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // How to Play button
            TextButton(
                onClick = { showHowToPlay = true },
                modifier = Modifier.testTag("how_to_play_button")
            ) {
                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = Color.Gray)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Nasıl Oynanır?", color = Color.Gray)
            }
        }
    }

    if (showHowToPlay) {
        HowToPlayDialog(onDismiss = { showHowToPlay = false })
    }
}

@Composable
fun GamePlayOverlay(
    state: GameUiState,
    onPauseGame: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top HUD Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color(0x880F172A), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Distance Counter
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF38BDF8))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${state.distanceMeters} m",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }

            // Coins Counter
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFFFACC15))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${state.runCoins}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFFACC15)
                )
            }

            // Pause Button
            IconButton(
                onClick = onPauseGame,
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0x55334155), CircleShape)
                    .testTag("pause_game_button")
            ) {
                Icon(Icons.Default.Pause, contentDescription = "Oyunu Duraklat", tint = Color.White)
            }
        }

        // Active Power-up Timers Bar
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 70.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (state.hasShield) {
                PowerUpTimerBadge(
                    label = "KALKAN",
                    timeLeftSec = state.shieldTimeLeftSec,
                    maxSec = 10f,
                    color = Color(0xFF38BDF8)
                )
            }
            if (state.isMagnetActive) {
                PowerUpTimerBadge(
                    label = "MINTATIS",
                    timeLeftSec = state.magnetTimeLeftSec,
                    maxSec = 8f,
                    color = Color(0xFFA855F7)
                )
            }
            if (state.isBoostActive) {
                PowerUpTimerBadge(
                    label = "TURBO",
                    timeLeftSec = state.boostTimeLeftSec,
                    maxSec = 4.5f,
                    color = Color(0xFF22D3EE)
                )
            }
            if (state.isMultiplierActive) {
                PowerUpTimerBadge(
                    label = "2X ALTIN",
                    timeLeftSec = state.multiplierTimeLeftSec,
                    maxSec = 10f,
                    color = Color(0xFF10B981)
                )
            }
        }

        // Touch Prompt
        Text(
            text = "YÜKSELMEN İÇİN EKRANA BASILI TUT",
            style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.sp),
            color = Color.White.copy(alpha = 0.6f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 20.dp)
        )
    }
}

@Composable
private fun PowerUpTimerBadge(
    label: String,
    timeLeftSec: Float,
    maxSec: Float,
    color: Color
) {
    Surface(
        color = Color(0xBB0F172A),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = color)
            Spacer(modifier = Modifier.width(8.dp))
            LinearProgressIndicator(
                progress = { (timeLeftSec / maxSec).coerceIn(0f, 1f) },
                color = color,
                trackColor = Color(0x33FFFFFF),
                modifier = Modifier
                    .width(60.dp)
                    .height(6.dp)
                    .clip(CircleShape)
            )
        }
    }
}

@Composable
fun PauseDialog(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onMenu: () -> Unit
) {
    Dialog(onDismissRequest = onResume) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "OYUN DURAKLATILDI",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onResume,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("resume_button")
                ) {
                    Text("DEVAM ET", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onRestart,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("restart_button")
                ) {
                    Text("YENİDEN BAŞLAT", color = Color.White)
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = onMenu,
                    modifier = Modifier.testTag("menu_button")
                ) {
                    Text("ANA MENÜYE DÖN", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun GameOverDialog(
    state: GameUiState,
    onPlayAgain: () -> Unit,
    onOpenShop: () -> Unit,
    onMenu: () -> Unit
) {
    Dialog(onDismissRequest = {}) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFEF4444)),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (state.isNewHighScore) {
                    Surface(
                        color = Color(0xFFFACC15),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(
                            "🏆 YENİ REKOR!",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.Black
                        )
                    }
                }

                Text(
                    "OYUN BİTTİ",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFEF4444)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Score stats card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x441E293B), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Mesafe", color = Color.Gray)
                        Text(
                            "${state.distanceMeters} metre",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Toplanan Altın", color = Color.Gray)
                        Text(
                            "+${state.runCoins} Altın",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFACC15)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onPlayAgain,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("play_again_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TEKRAR OYNA", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onOpenShop,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mağaza", color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onMenu,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Ana Menü", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ShopScreen(
    state: GameUiState,
    onPurchaseSkin: (JetpackSkin) -> Unit,
    onUpgradeStat: (String, Int) -> Unit,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Skins, 1 = Upgrades

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(20.dp)
    ) {
        // Top Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("back_from_shop_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = Color.White)
            }

            Text(
                "JETPACK MAĞAZASI",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFFFACC15))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    "${state.userStats.totalCoins}",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFACC15)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x441E293B), RoundedCornerShape(14.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectedTab == 0) Color(0xFF0284C7) else Color.Transparent)
                    .clickable { selectedTab = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("JETPACK SKİNLERİ", fontWeight = FontWeight.Bold, color = Color.White)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectedTab == 1) Color(0xFF0284C7) else Color.Transparent)
                    .clickable { selectedTab = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("GÜÇLENDİRMELER", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(JetpackSkin.ALL_SKINS) { skin ->
                    val unlockedList = state.userStats.unlockedSkinIds.split(",")
                    val isUnlocked = unlockedList.contains(skin.id)
                    val isEquipped = state.equippedSkin.id == skin.id

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Color preview circle
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(skin.primaryColor, CircleShape)
                                        .border(3.dp, skin.secondaryColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .background(skin.flameColor, CircleShape)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(skin.name, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text(skin.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                            }

                            if (isEquipped) {
                                Surface(
                                    color = Color(0xFF10B981),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        "KUŞANILDI",
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            } else if (isUnlocked) {
                                Button(
                                    onClick = { onPurchaseSkin(skin) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("KUŞAN")
                                }
                            } else {
                                val canAfford = state.userStats.totalCoins >= skin.cost
                                Button(
                                    onClick = { onPurchaseSkin(skin) },
                                    enabled = canAfford,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFACC15)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("${skin.cost} Altın", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Upgrades list
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                UpgradeCard(
                    title = "Kalkan Süresi",
                    level = state.userStats.shieldLevel,
                    icon = Icons.Default.Shield,
                    color = Color(0xFF38BDF8),
                    cost = state.userStats.shieldLevel * 300,
                    userCoins = state.userStats.totalCoins,
                    onUpgrade = { onUpgradeStat("shield", state.userStats.shieldLevel * 300) }
                )

                UpgradeCard(
                    title = "Mıknatıs Gücü",
                    level = state.userStats.magnetLevel,
                    icon = Icons.Default.Star,
                    color = Color(0xFFA855F7),
                    cost = state.userStats.magnetLevel * 300,
                    userCoins = state.userStats.totalCoins,
                    onUpgrade = { onUpgradeStat("magnet", state.userStats.magnetLevel * 300) }
                )

                UpgradeCard(
                    title = "Çarpan Bonusu",
                    level = state.userStats.multiplierLevel,
                    icon = Icons.Default.MonetizationOn,
                    color = Color(0xFF10B981),
                    cost = state.userStats.multiplierLevel * 400,
                    userCoins = state.userStats.totalCoins,
                    onUpgrade = { onUpgradeStat("multiplier", state.userStats.multiplierLevel * 400) }
                )
            }
        }
    }
}

@Composable
private fun UpgradeCard(
    title: String,
    level: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    cost: Int,
    userCoins: Int,
    onUpgrade: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(color.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color)
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(title, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Seviye $level", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }

            Button(
                onClick = onUpgrade,
                enabled = userCoins >= cost,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFACC15)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("$cost Altın", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun LeaderboardScreen(
    state: GameUiState,
    onBack: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("back_from_leaderboard_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = Color.White)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                "EN YÜKSEK SKORLAR",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (state.topHighScores.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Henüz skor kaydı yok. İlk rekoru sen kır!",
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(state.topHighScores) { index, score ->
                    val badgeColor = when (index) {
                        0 -> Color(0xFFFACC15) // Gold
                        1 -> Color(0xFF94A3B8) // Silver
                        2 -> Color(0xFFB45309) // Bronze
                        else -> Color(0x33FFFFFF)
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(badgeColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "#${index + 1}",
                                        fontWeight = FontWeight.Black,
                                        color = if (index < 3) Color.Black else Color.White
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        "${score.distanceMeters} Metre",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        dateFormat.format(Date(score.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFFFACC15), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "${score.coinsCollected}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFACC15)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HowToPlayDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "NASIL OYNANIR?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    GuideItem(
                        icon = Icons.Default.Bolt,
                        color = Color(0xFF38BDF8),
                        title = "Kontroller",
                        description = "Ekrana basılı tutarak roketinizi ateşleyin ve yükselin. Bıraktığınızda yerçekimi ile alçalın."
                    )

                    GuideItem(
                        icon = Icons.Default.Shield,
                        color = Color(0xFFEF4444),
                        title = "Engeller",
                        description = "Elektrikli zapper'lardan, arkanızdan gelen roketlerden ve kırmızı lazerlerden kaçının!"
                    )

                    GuideItem(
                        icon = Icons.Default.MonetizationOn,
                        color = Color(0xFFFACC15),
                        title = "Altınlar ve Güçlendirmeler",
                        description = "Altınları toplayın. Kalkan, Mıknatıs, Süper Turbo ve 2X Altın güçlendirmelerini kapın!"
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ANLADIM!", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun GuideItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    title: String,
    description: String
) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(color.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold, color = Color.White)
            Text(description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}
