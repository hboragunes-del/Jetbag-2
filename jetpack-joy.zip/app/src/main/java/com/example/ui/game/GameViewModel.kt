package com.example.ui.game

import android.app.Application
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.GameDatabase
import com.example.data.repository.GameRepository
import com.example.domain.model.Collectible
import com.example.domain.model.JetpackSkin
import com.example.domain.model.Obstacle
import com.example.domain.model.Particle
import com.example.domain.model.PowerUpType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GameRepository
    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var nextObjectId = 1L
    private var spawnTimer = 0f
    private var coinSpawnTimer = 0f
    private var powerUpSpawnTimer = 0f
    private var distanceAccumulator = 0f

    // Screen bounds initialized dynamically
    private var canvasWidth = 1080f
    private var canvasHeight = 1920f
    private var ceilingY = 80f
    private var floorY = 1750f

    init {
        val db = GameDatabase.getDatabase(application)
        repository = GameRepository(db.gameDao())

        viewModelScope.launch {
            repository.userStats.collect { stats ->
                val skin = JetpackSkin.getById(stats.equippedSkinId)
                _uiState.update { state ->
                    state.copy(
                        userStats = stats,
                        equippedSkin = skin
                    )
                }
            }
        }

        viewModelScope.launch {
            repository.topHighScores.collect { scores ->
                _uiState.update { state ->
                    state.copy(topHighScores = scores)
                }
            }
        }
    }

    fun setCanvasDimensions(width: Float, height: Float) {
        if (width <= 0 || height <= 0) return
        canvasWidth = width
        canvasHeight = height
        ceilingY = height * 0.08f
        floorY = height * 0.90f
        
        _uiState.update { state ->
            if (state.gameMode == GameMode.MENU) {
                state.copy(playerY = (ceilingY + floorY) / 2f)
            } else state
        }
    }

    fun onThrustChange(isThrusting: Boolean) {
        _uiState.update { it.copy(isThrusting = isThrusting) }
    }

    fun startGame() {
        val startY = (ceilingY + floorY) / 2f
        _uiState.update { state ->
            state.copy(
                gameMode = GameMode.PLAYING,
                playerY = startY,
                playerVy = 0f,
                distanceMeters = 0,
                runCoins = 0,
                hasShield = false,
                shieldTimeLeftSec = 0f,
                isMagnetActive = false,
                magnetTimeLeftSec = 0f,
                isBoostActive = false,
                boostTimeLeftSec = 0f,
                isMultiplierActive = false,
                multiplierTimeLeftSec = 0f,
                obstacles = emptyList(),
                collectibles = emptyList(),
                particles = emptyList(),
                floatingTexts = emptyList(),
                isNewHighScore = false
            )
        }
        spawnTimer = 0f
        coinSpawnTimer = 0f
        powerUpSpawnTimer = 0f
        distanceAccumulator = 0f
    }

    fun pauseGame() {
        _uiState.update { it.copy(gameMode = GameMode.PAUSED) }
    }

    fun resumeGame() {
        _uiState.update { it.copy(gameMode = GameMode.PLAYING) }
    }

    fun openShop() {
        _uiState.update { it.copy(gameMode = GameMode.SHOP) }
    }

    fun openLeaderboard() {
        _uiState.update { it.copy(gameMode = GameMode.LEADERBOARD) }
    }

    fun backToMenu() {
        _uiState.update { it.copy(gameMode = GameMode.MENU) }
    }

    fun updateGameTick(dtSec: Float) {
        val currentState = _uiState.value
        if (currentState.gameMode != GameMode.PLAYING) return

        // 1. Calculate speeds and bonuses
        val baseSpeed = 480f + (currentState.distanceMeters * 0.4f).coerceAtMost(400f)
        val currentSpeed = if (currentState.isBoostActive) baseSpeed * 1.8f else baseSpeed
        val scrollDx = currentSpeed * dtSec

        // 2. Player Physics
        val gravity = 1100f // px / s^2
        val thrust = -1800f  // px / s^2 upward acceleration
        val accY = if (currentState.isThrusting) thrust else gravity
        var newVy = currentState.playerVy + accY * dtSec
        newVy = newVy.coerceIn(-900f, 900f)

        var newY = currentState.playerY + newVy * dtSec
        if (newY < ceilingY + currentState.playerRadius) {
            newY = ceilingY + currentState.playerRadius
            newVy = 0f
        } else if (newY > floorY - currentState.playerRadius) {
            newY = floorY - currentState.playerRadius
            newVy = 0f
        }

        // 3. Distance Accumulation
        distanceAccumulator += (currentSpeed * dtSec) / 25f
        val newDistance = distanceAccumulator.toInt()

        // 4. Power-up Timers
        val newShieldTime = (currentState.shieldTimeLeftSec - dtSec).coerceAtLeast(0f)
        val newMagnetTime = (currentState.magnetTimeLeftSec - dtSec).coerceAtLeast(0f)
        val newBoostTime = (currentState.boostTimeLeftSec - dtSec).coerceAtLeast(0f)
        val newMultiplierTime = (currentState.multiplierTimeLeftSec - dtSec).coerceAtLeast(0f)

        val hasShield = newShieldTime > 0f || (currentState.hasShield && newShieldTime <= 0f && currentState.shieldTimeLeftSec > 0f)
        val isMagnet = newMagnetTime > 0f
        val isBoost = newBoostTime > 0f
        val isMultiplier = newMultiplierTime > 0f

        // 5. Thruster Particles
        val newParticles = currentState.particles.toMutableList()
        if (currentState.isThrusting || isBoost) {
            val skin = currentState.equippedSkin
            for (i in 0..2) {
                newParticles.add(
                    Particle(
                        x = currentState.playerX - 25f + Random.nextFloat() * 10f,
                        y = newY + 20f + Random.nextFloat() * 8f,
                        vx = -250f - Random.nextFloat() * 150f,
                        vy = 100f + Random.nextFloat() * 200f,
                        color = if (isBoost) Color(0xFF38BDF8) else skin.flameColor,
                        size = 8f + Random.nextFloat() * 12f,
                        maxLife = 0.35f
                    )
                )
            }
        }

        // Update existing particles
        val updatedParticles = newParticles.mapNotNull { p ->
            val lifeLeft = p.currentLife - dtSec
            if (lifeLeft <= 0) null
            else p.copy(
                x = p.x + p.vx * dtSec,
                y = p.y + p.vy * dtSec,
                currentLife = lifeLeft,
                alpha = (lifeLeft / p.maxLife).coerceIn(0f, 1f)
            )
        }.toMutableList()

        // 6. Floating Texts Update
        val updatedFloatingTexts = currentState.floatingTexts.mapNotNull { ft ->
            val lifeLeft = ft.lifeSec - dtSec
            if (lifeLeft <= 0) null
            else ft.copy(
                y = ft.y - 40f * dtSec,
                lifeSec = lifeLeft
            )
        }

        // 7. Spawning Obstacles & Collectibles
        spawnTimer += dtSec
        if (spawnTimer > (1.8f - (currentState.distanceMeters * 0.0005f).coerceAtMost(0.9f))) {
            spawnTimer = 0f
            val newObs = generateRandomObstacle(canvasWidth, ceilingY, floorY)
            _uiState.value = _uiState.value.copy(obstacles = _uiState.value.obstacles + newObs)
        }

        coinSpawnTimer += dtSec
        if (coinSpawnTimer > 2.5f) {
            coinSpawnTimer = 0f
            val newCoins = generateCoinGroup(canvasWidth, ceilingY, floorY)
            _uiState.value = _uiState.value.copy(collectibles = _uiState.value.collectibles + newCoins)
        }

        powerUpSpawnTimer += dtSec
        if (powerUpSpawnTimer > 12.0f) {
            powerUpSpawnTimer = 0f
            val powerUp = generatePowerUp(canvasWidth, ceilingY, floorY)
            _uiState.value = _uiState.value.copy(collectibles = _uiState.value.collectibles + powerUp)
        }

        // 8. Update & Move Obstacles
        val updatedObstacles = mutableListOf<Obstacle>()
        var playerCrashed = false

        for (obs in _uiState.value.obstacles) {
            when (obs) {
                is Obstacle.Zapper -> {
                    val nextX = obs.x - scrollDx
                    val updatedObs = obs.copy(x = nextX)
                    if (nextX > -250f) {
                        updatedObstacles.add(updatedObs)
                        // Collision check
                        if (checkZapperCollision(currentState.playerX, newY, currentState.playerRadius, updatedObs)) {
                            if (isBoost) {
                                createExplosionParticles(updatedParticles, updatedObs.x, updatedObs.y, Color(0xFFF59E0B))
                            } else if (currentState.hasShield) {
                                createExplosionParticles(updatedParticles, currentState.playerX, newY, Color(0xFF38BDF8))
                                _uiState.update { it.copy(hasShield = false, shieldTimeLeftSec = 0f) }
                            } else {
                                playerCrashed = true
                            }
                        }
                    }
                }
                is Obstacle.Missile -> {
                    var warningTime = obs.warningTimerSec
                    var nextX = obs.x
                    if (warningTime > 0f) {
                        warningTime -= dtSec
                    } else {
                        nextX -= (scrollDx + obs.speed * 60f * dtSec)
                    }
                    val updatedObs = obs.copy(x = nextX, warningTimerSec = warningTime)
                    if (nextX > -100f) {
                        updatedObstacles.add(updatedObs)
                        if (warningTime <= 0f && checkCircleCollision(currentState.playerX, newY, currentState.playerRadius, nextX, obs.y, 22f)) {
                            if (isBoost) {
                                createExplosionParticles(updatedParticles, updatedObs.x, updatedObs.y, Color(0xFFEF4444))
                            } else if (currentState.hasShield) {
                                createExplosionParticles(updatedParticles, currentState.playerX, newY, Color(0xFF38BDF8))
                                _uiState.update { it.copy(hasShield = false, shieldTimeLeftSec = 0f) }
                            } else {
                                playerCrashed = true
                            }
                        }
                    }
                }
                is Obstacle.LaserField -> {
                    val nextX = obs.x - scrollDx
                    var timer = obs.cycleTimerSec + dtSec
                    var active = obs.isActive
                    if (timer > 2.0f) {
                        timer = 0f
                        active = !active
                    }
                    val updatedObs = obs.copy(x = nextX, cycleTimerSec = timer, isActive = active)
                    if (nextX > -150f) {
                        updatedObstacles.add(updatedObs)
                        if (active && checkLaserCollision(currentState.playerX, newY, currentState.playerRadius, updatedObs)) {
                            if (isBoost) {
                                // invincible
                            } else if (currentState.hasShield) {
                                createExplosionParticles(updatedParticles, currentState.playerX, newY, Color(0xFF38BDF8))
                                _uiState.update { it.copy(hasShield = false, shieldTimeLeftSec = 0f) }
                            } else {
                                playerCrashed = true
                            }
                        }
                    }
                }
            }
        }

        // 9. Update & Collect Collectibles
        val updatedCollectibles = mutableListOf<Collectible>()
        var runCoinsEarned = currentState.runCoins
        var activatedShield = currentState.hasShield
        var activatedShieldTimer = newShieldTime
        var activatedMagnetTimer = newMagnetTime
        var activatedBoostTimer = newBoostTime
        var activatedMultiplierTimer = newMultiplierTime
        val newFloatingTexts = updatedFloatingTexts.toMutableList()

        for (col in _uiState.value.collectibles) {
            if (col.isCollected) continue
            var cx = col.x - scrollDx
            var cy = col.y

            // Magnet pull effect
            if (col is Collectible.Coin && isMagnet) {
                val dx = currentState.playerX - cx
                val dy = newY - cy
                val distSq = dx * dx + dy * dy
                if (distSq < 380f * 380f) {
                    val angle = atan2(dy, dx)
                    cx += cos(angle) * 700f * dtSec
                    cy += sin(angle) * 700f * dtSec
                }
            }

            if (cx > -60f) {
                val isColliding = checkCircleCollision(currentState.playerX, newY, currentState.playerRadius + 8f, cx, cy, 20f)
                if (isColliding) {
                    when (col) {
                        is Collectible.Coin -> {
                            val valueMultiplier = if (isMultiplier) 2 else 1
                            val coinsToAdd = col.value * valueMultiplier
                            runCoinsEarned += coinsToAdd
                            createCoinSparkParticles(updatedParticles, cx, cy)
                            newFloatingTexts.add(
                                FloatingText(
                                    id = System.nanoTime(),
                                    text = "+$coinsToAdd",
                                    x = cx,
                                    y = cy,
                                    colorHex = 0xFFFACC15
                                )
                            )
                        }
                        is Collectible.PowerUp -> {
                            val durationBonus = (currentState.userStats.shieldLevel * 1.5f)
                            when (col.type) {
                                PowerUpType.SHIELD -> {
                                    activatedShield = true
                                    activatedShieldTimer = 10f + durationBonus
                                    newFloatingTexts.add(FloatingText(System.nanoTime(), "KALKAN ON!", cx, cy, colorHex = 0xFF38BDF8))
                                }
                                PowerUpType.MAGNET -> {
                                    activatedMagnetTimer = 8f + durationBonus
                                    newFloatingTexts.add(FloatingText(System.nanoTime(), "MUKATIS ON!", cx, cy, colorHex = 0xFFA855F7))
                                }
                                PowerUpType.BOOST -> {
                                    activatedBoostTimer = 4.5f
                                    newFloatingTexts.add(FloatingText(System.nanoTime(), "SUPER TURBO!", cx, cy, colorHex = 0xFF22D3EE))
                                }
                                PowerUpType.MULTIPLIER -> {
                                    activatedMultiplierTimer = 10f + durationBonus
                                    newFloatingTexts.add(FloatingText(System.nanoTime(), "2X COINS!", cx, cy, colorHex = 0xFF10B981))
                                }
                            }
                            createExplosionParticles(updatedParticles, cx, cy, Color(0xFF38BDF8))
                        }
                    }
                } else {
                    when (col) {
                        is Collectible.Coin -> updatedCollectibles.add(col.copy(x = cx, y = cy))
                        is Collectible.PowerUp -> updatedCollectibles.add(col.copy(x = cx, y = cy))
                    }
                }
            }
        }

        // 10. Check if player crashed
        if (playerCrashed) {
            createExplosionParticles(updatedParticles, currentState.playerX, newY, Color(0xFFEF4444))
            handleGameOver(newDistance, runCoinsEarned)
            _uiState.update {
                it.copy(
                    gameMode = GameMode.GAME_OVER,
                    playerY = newY,
                    playerVy = 0f,
                    particles = updatedParticles
                )
            }
            return
        }

        // 11. Background Scroll Offset
        val newBgOffset = (currentState.backgroundOffset + scrollDx) % canvasWidth

        // 12. Commit state update
        _uiState.update { state ->
            state.copy(
                playerY = newY,
                playerVy = newVy,
                distanceMeters = newDistance,
                runCoins = runCoinsEarned,
                hasShield = activatedShield,
                shieldTimeLeftSec = activatedShieldTimer,
                isMagnetActive = activatedMagnetTimer > 0f,
                magnetTimeLeftSec = activatedMagnetTimer,
                isBoostActive = activatedBoostTimer > 0f,
                boostTimeLeftSec = activatedBoostTimer,
                isMultiplierActive = activatedMultiplierTimer > 0f,
                multiplierTimeLeftSec = activatedMultiplierTimer,
                obstacles = updatedObstacles,
                collectibles = updatedCollectibles,
                particles = updatedParticles,
                floatingTexts = newFloatingTexts,
                backgroundOffset = newBgOffset
            )
        }
    }

    private fun handleGameOver(finalDistance: Int, finalCoins: Int) {
        viewModelScope.launch {
            repository.addCoinsAndRecordDistance(finalCoins, finalDistance)
            val currentBest = _uiState.value.userStats.highestDistance
            val isNewRecord = finalDistance > currentBest
            if (isNewRecord) {
                _uiState.update { it.copy(isNewHighScore = true) }
            }
            repository.saveHighScore(
                distanceMeters = finalDistance,
                coinsCollected = finalCoins,
                jetpackSkinId = _uiState.value.equippedSkin.id
            )
        }
    }

    fun purchaseSkin(skin: JetpackSkin) {
        viewModelScope.launch {
            val stats = _uiState.value.userStats
            val isUnlocked = stats.unlockedSkinIds.split(",").contains(skin.id)
            if (isUnlocked) {
                repository.equipSkin(skin.id)
            } else {
                repository.unlockSkin(skin.id, skin.cost)
            }
        }
    }

    fun upgradeStat(statType: String, cost: Int) {
        viewModelScope.launch {
            repository.upgradeStat(statType, cost)
        }
    }

    // Helper Spawners
    private fun generateRandomObstacle(width: Float, topY: Float, bottomY: Float): Obstacle {
        nextObjectId++
        val type = Random.nextInt(3)
        val usableHeight = bottomY - topY - 120f
        val randomY = topY + 60f + Random.nextFloat() * usableHeight

        return when (type) {
            0 -> { // Zapper
                Obstacle.Zapper(
                    id = nextObjectId,
                    x = width + 100f,
                    y = randomY,
                    length = 150f + Random.nextFloat() * 60f,
                    angleDeg = listOf(0f, 45f, 90f, 135f).random()
                )
            }
            1 -> { // Missile
                Obstacle.Missile(
                    id = nextObjectId,
                    x = width + 60f,
                    y = randomY,
                    speed = 12f + Random.nextFloat() * 8f
                )
            }
            else -> { // LaserField
                val laserTop = (topY + Random.nextFloat() * (usableHeight - 200f)).coerceAtLeast(topY + 30f)
                Obstacle.LaserField(
                    id = nextObjectId,
                    x = width + 80f,
                    topY = laserTop,
                    bottomY = laserTop + 180f
                )
            }
        }
    }

    private fun generateCoinGroup(width: Float, topY: Float, bottomY: Float): List<Collectible.Coin> {
        val coins = mutableListOf<Collectible.Coin>()
        val startX = width + 80f
        val usableHeight = bottomY - topY - 140f
        val startY = topY + 70f + Random.nextFloat() * usableHeight
        val pattern = Random.nextInt(3)

        when (pattern) {
            0 -> { // Horizontal line
                for (i in 0..5) {
                    nextObjectId++
                    coins.add(Collectible.Coin(nextObjectId, startX + i * 45f, startY))
                }
            }
            1 -> { // Sine Wave
                for (i in 0..7) {
                    nextObjectId++
                    val yOffset = sin(i * 0.6f) * 70f
                    coins.add(Collectible.Coin(nextObjectId, startX + i * 42f, (startY + yOffset).coerceIn(topY + 40f, bottomY - 40f)))
                }
            }
            2 -> { // Grid Block 3x3
                for (row in 0..2) {
                    for (col in 0..2) {
                        nextObjectId++
                        coins.add(Collectible.Coin(nextObjectId, startX + col * 42f, startY + row * 42f))
                    }
                }
            }
        }
        return coins
    }

    private fun generatePowerUp(width: Float, topY: Float, bottomY: Float): Collectible.PowerUp {
        nextObjectId++
        val usableHeight = bottomY - topY - 120f
        val randomY = topY + 60f + Random.nextFloat() * usableHeight
        val type = PowerUpType.entries.random()
        return Collectible.PowerUp(
            id = nextObjectId,
            x = width + 100f,
            y = randomY,
            type = type
        )
    }

    // Helper Collision Checks
    private fun checkCircleCollision(x1: Float, y1: Float, r1: Float, x2: Float, y2: Float, r2: Float): Boolean {
        val dx = x1 - x2
        val dy = y1 - y2
        val distSq = dx * dx + dy * dy
        val minDist = r1 + r2
        return distSq <= minDist * minDist
    }

    private fun checkZapperCollision(px: Float, py: Float, pr: Float, zapper: Obstacle.Zapper): Boolean {
        val rad = Math.toRadians(zapper.angleDeg.toDouble())
        val halfLen = zapper.length / 2f
        val x1 = zapper.x - cos(rad).toFloat() * halfLen
        val y1 = zapper.y - sin(rad).toFloat() * halfLen
        val x2 = zapper.x + cos(rad).toFloat() * halfLen
        val y2 = zapper.y + sin(rad).toFloat() * halfLen

        // Distance from point (px, py) to line segment (x1,y1) -> (x2,y2)
        val l2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)
        if (l2 == 0f) return checkCircleCollision(px, py, pr, x1, y1, 15f)
        var t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2
        t = t.coerceIn(0f, 1f)
        val projX = x1 + t * (x2 - x1)
        val projY = y1 + t * (y2 - y1)
        return checkCircleCollision(px, py, pr, projX, projY, 14f)
    }

    private fun checkLaserCollision(px: Float, py: Float, pr: Float, laser: Obstacle.LaserField): Boolean {
        if (px + pr < laser.x - laser.width / 2f || px - pr > laser.x + laser.width / 2f) return false
        return py + pr >= laser.topY && py - pr <= laser.bottomY
    }

    private fun createExplosionParticles(particles: MutableList<Particle>, x: Float, y: Float, color: Color) {
        for (i in 0..24) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = 150f + Random.nextFloat() * 300f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    color = color,
                    size = 6f + Random.nextFloat() * 10f,
                    maxLife = 0.5f
                )
            )
        }
    }

    private fun createCoinSparkParticles(particles: MutableList<Particle>, x: Float, y: Float) {
        for (i in 0..8) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = 80f + Random.nextFloat() * 140f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    color = Color(0xFFFACC15),
                    size = 5f + Random.nextFloat() * 6f,
                    maxLife = 0.3f
                )
            )
        }
    }
}
