package com.example.ui.game

import com.example.data.db.HighScoreEntity
import com.example.data.db.UserStatsEntity
import com.example.domain.model.Collectible
import com.example.domain.model.JetpackSkin
import com.example.domain.model.Obstacle
import com.example.domain.model.Particle

enum class GameMode {
    MENU,
    PLAYING,
    PAUSED,
    GAME_OVER,
    SHOP,
    LEADERBOARD
}

data class FloatingText(
    val id: Long,
    val text: String,
    var x: Float,
    var y: Float,
    var lifeSec: Float = 1.0f,
    val colorHex: Long = 0xFFFACC15
)

data class GameUiState(
    val gameMode: GameMode = GameMode.MENU,
    val playerY: Float = 400f,
    val playerVy: Float = 0f,
    val isThrusting: Boolean = false,
    val playerX: Float = 180f,
    val playerRadius: Float = 24f,
    val distanceMeters: Int = 0,
    val runCoins: Int = 0,
    
    // Active power-up durations
    val hasShield: Boolean = false,
    val shieldTimeLeftSec: Float = 0f,
    val isMagnetActive: Boolean = false,
    val magnetTimeLeftSec: Float = 0f,
    val isBoostActive: Boolean = false,
    val boostTimeLeftSec: Float = 0f,
    val isMultiplierActive: Boolean = false,
    val multiplierTimeLeftSec: Float = 0f,
    
    // Stats & Inventory from Room
    val userStats: UserStatsEntity = UserStatsEntity(),
    val topHighScores: List<HighScoreEntity> = emptyList(),
    val equippedSkin: JetpackSkin = JetpackSkin.ALL_SKINS.first(),
    
    // Dynamic game objects
    val obstacles: List<Obstacle> = emptyList(),
    val collectibles: List<Collectible> = emptyList(),
    val particles: List<Particle> = emptyList(),
    val floatingTexts: List<FloatingText> = emptyList(),
    
    // Environment animation offset
    val backgroundOffset: Float = 0f,
    
    // Run summary flags
    val isNewHighScore: Boolean = false
)
